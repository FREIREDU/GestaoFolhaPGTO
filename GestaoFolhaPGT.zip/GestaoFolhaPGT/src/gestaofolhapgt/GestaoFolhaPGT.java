package gestaofolhapgt;

public class GestaoFolhaPGT {

    public static void main(String[] args) {
    }
    
}
